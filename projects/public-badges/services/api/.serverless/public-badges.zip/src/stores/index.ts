import badgeClass from "./badgeClass";
import badgeInstance from "./badgeInstance";
import registry from "./registry";

export { badgeClass, badgeInstance, registry };
