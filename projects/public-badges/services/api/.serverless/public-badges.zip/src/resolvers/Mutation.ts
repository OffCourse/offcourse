import badgeClass from "../fixtures/badgeClass.json";
import { MutationResolvers, Status } from "../generated/graphql.js";
import uuidv5 from "uuid/v5";
import { PublicBadgesEventType } from "../types.js";

const Mutation: MutationResolvers = {
  addBadgeClass() {
    return badgeClass;
  },
  registerOrganization(_root, { input }, { datalake }) {
    const uuid = uuidv5("publicspaces.org", uuidv5.DNS);
    const payload = {
      ...input,
      path: `organizations/${uuid}/meta.json`,
      organizationId: `urn:uuid:${uuid}`,
      status: Status.Requested
    };
    return datalake.dump(
      PublicBadgesEventType.ORGANIZATION_REQUESTED_REGISTRATION,
      payload
    );
  }
};

export default Mutation;
