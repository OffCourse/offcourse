import { BWAService } from "@bwa/botframe";

type BWAState = BWAService["state"];

export { BWAService, BWAState };
