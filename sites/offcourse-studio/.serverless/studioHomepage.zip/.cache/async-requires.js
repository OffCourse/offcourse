// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---themes-homepage-theme-src-templates-home-page-tsx": () => import("../../../themes/homepage-theme/src/templates/HomePage.tsx" /* webpackChunkName: "component---themes-homepage-theme-src-templates-home-page-tsx" */)
}

