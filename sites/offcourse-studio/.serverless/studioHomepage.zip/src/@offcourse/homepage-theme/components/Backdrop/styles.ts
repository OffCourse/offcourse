export const wrapperStyles = {
  position: "absolute",
  bg: "primary",
  zIndex: -1,
  top: 0,
  left: 0
};
