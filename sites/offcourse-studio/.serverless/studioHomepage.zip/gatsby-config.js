module.exports = {
  siteMetadata: {
    siteName: `Offcourse Studio_`
  },
  plugins: ["@offcourse/homepage-theme"]
};
