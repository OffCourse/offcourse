const https = require("https");

module.exports.contact = (event, context, callback) => {
  const payload = JSON.stringify(event.formData);
  console.log(payload);
  // const options = {
  //   hostname: "hooks.slack.com",
  //   method: "POST",
  //   path: "/services/ABC1234/CDE5677/SomeSecret123"
  // };

  // const req = https.request(options, res =>
  //   res.on("data", () => callback(null, "OK"))
  // );
  // req.on("error", error => callback(JSON.stringify(error)));
  // req.write(payload);
  // req.end();
};
