export default {
  typescript: true,
  themeConfig: {
    mode: "dark"
  }
};
