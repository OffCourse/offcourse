module.exports = {
  plugins: [`gatsby-plugin-typescript`, "gatsby-theme-docz"]
};
